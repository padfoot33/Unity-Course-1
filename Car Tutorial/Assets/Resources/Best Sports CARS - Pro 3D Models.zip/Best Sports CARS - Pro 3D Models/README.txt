To drive a car, you need to download the standard asset "Vehicle".

Assets > Import Package > Vehicle

After, load the scene Vehicle/SportCar0X/Demo/SceneDriverXX


